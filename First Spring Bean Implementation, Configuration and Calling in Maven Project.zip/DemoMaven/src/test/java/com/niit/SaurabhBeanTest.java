package com.niit;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SaurabhBeanTest 
{
     public static void main(String arg[])
     {
    	 AnnotationConfigApplicationContext saurabhcontext = new AnnotationConfigApplicationContext();
    	 
    	 saurabhcontext.scan("com.niit");
    	 
    	 saurabhcontext.refresh();
    	 
    	 SaurabhBean Saurabh_Bean = (SaurabhBean)saurabhcontext.getBean("Saurabh_Bean");
    	 saurabhcontext.close();
    	 
    	 Saurabh_Bean.display();
    	 
    	
     }
}
