package com.niit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SaurabhConfiguration 
{
   @Bean("Saurabh_Bean")	// Same as SpringConfig.xml command: <bean id="Saurabh's Bean" class="com.SaurabhBean"/> //
      public SaurabhBean getSaurabhBean()
      {
    	  System.out.println("The Bean: SaurabhBean will be executed now!");
    	  return new SaurabhBean();
      }
}
