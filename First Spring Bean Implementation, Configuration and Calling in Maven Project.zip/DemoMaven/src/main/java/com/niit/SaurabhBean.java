package com.niit;

public class SaurabhBean 
{
    public void display() 
    {
    	System.out.println("Your are inside class SaurabhBean's display method!!");
    }
}
